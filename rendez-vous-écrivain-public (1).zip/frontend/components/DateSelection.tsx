import React, { useMemo } from 'react';
import { Calendar as CalendarIcon, ChevronRight } from 'lucide-react';
import { getNextAvailableDays, formatShortDate, formatDate } from '../utils/dateUtils';

interface DateSelectionProps {
  selectedDate: Date | null;
  onSelectDate: (date: Date) => void;
  onNext: () => void;
}

const DateSelection: React.FC<DateSelectionProps> = ({ selectedDate, onSelectDate, onNext }) => {
  const availableDays = useMemo(() => getNextAvailableDays(12), []);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 flex items-center">
          <CalendarIcon className="w-6 h-6 mr-2 text-brand-600" />
          Choisissez une date
        </h2>
        <p className="text-slate-500 mt-1">Sélectionnez l'un des prochains jours de permanence disponibles.</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-8">
        {availableDays.map((date, index) => {
          const { dayName, dayNumber, month } = formatShortDate(date);
          const isSelected = selectedDate?.getTime() === date.getTime();
          
          return (
            <button
              key={index}
              onClick={() => onSelectDate(date)}
              className={`
                flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all duration-200
                ${isSelected 
                  ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-md scale-105' 
                  : 'border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:bg-slate-50'}
              `}
            >
              <span className="text-sm font-medium uppercase tracking-wider mb-1">{dayName}</span>
              <span className="text-2xl font-bold mb-1">{dayNumber}</span>
              <span className="text-sm">{month}</span>
            </button>
          );
        })}
      </div>

      <div className="flex justify-between items-center pt-6 border-t border-slate-100">
        <div className="text-sm text-slate-500">
          {selectedDate ? (
            <span>Sélection : <strong className="text-slate-800">{formatDate(selectedDate)}</strong></span>
          ) : (
            <span>Aucune date sélectionnée</span>
          )}
        </div>
        <button
          onClick={onNext}
          disabled={!selectedDate}
          className={`
            flex items-center px-6 py-3 rounded-lg font-semibold transition-all
            ${selectedDate 
              ? 'bg-brand-600 text-white hover:bg-brand-700 shadow-md hover:shadow-lg' 
              : 'bg-slate-100 text-slate-400 cursor-not-allowed'}
          `}
        >
          Continuer
          <ChevronRight className="w-5 h-5 ml-2" />
        </button>
      </div>
    </div>
  );
};

export default DateSelection;
