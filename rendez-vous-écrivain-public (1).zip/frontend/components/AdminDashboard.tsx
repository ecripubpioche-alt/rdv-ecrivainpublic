import React, { useState, useEffect } from 'react';
import { Users, Calendar, Clock, CheckCircle2, XCircle, Search, Lock, Key, AlertCircle } from 'lucide-react';
import { Appointment } from '../types';
import { getAllAppointments } from '../services/storageService';
import { formatDate } from '../utils/dateUtils';

const AdminDashboard: React.FC = () => {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');

  // Dashboard state
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'cancelled'>('all');

  useEffect(() => {
    if (isAuthenticated) {
      // Load appointments only when authenticated
      setAppointments(getAllAppointments());
    }
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'Metz57000') {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Mot de passe incorrect.');
      setPassword('');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto w-full bg-white rounded-3xl shadow-xl overflow-hidden p-8 animate-in fade-in duration-500 mt-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-4 bg-slate-100 rounded-full mb-4">
            <Lock className="w-8 h-8 text-slate-700" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">Accès Sécurisé</h2>
          <p className="text-slate-500 mt-2">Espace réservé à l'écrivain public.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mot de passe"
                className={`w-full pl-12 pr-4 py-3 border-2 rounded-xl focus:ring-0 outline-none transition-all ${
                  authError ? 'border-red-300 focus:border-red-500' : 'border-slate-200 focus:border-slate-800'
                }`}
                autoFocus
              />
              <Key className={`absolute left-4 top-3.5 w-5 h-5 ${authError ? 'text-red-400' : 'text-slate-400'}`} />
            </div>
            {authError && (
              <p className="text-red-500 text-sm mt-2 flex items-center animate-in slide-in-from-top-1">
                <AlertCircle className="w-4 h-4 mr-1" /> {authError}
              </p>
            )}
          </div>
          <button
            type="submit"
            className="w-full bg-slate-800 text-white py-3 rounded-xl font-semibold hover:bg-slate-900 transition-colors shadow-md hover:shadow-lg"
          >
            Se connecter
          </button>
        </form>
      </div>
    );
  }

  const filteredAppointments = appointments.filter(app => {
    const matchesSearch = 
      app.user.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.user.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filter === 'all' || app.status === filter;

    return matchesSearch && matchesFilter;
  });

  // Sort: upcoming active first, then past active, then cancelled
  const sortedAppointments = [...filteredAppointments].sort((a, b) => {
    if (a.status !== b.status) {
      return a.status === 'active' ? -1 : 1;
    }
    return b.date.getTime() - a.date.getTime(); // Newest first for admin view usually better, or closest first. Let's do closest first.
  }).reverse();

  return (
    <div className="max-w-6xl mx-auto w-full bg-white rounded-3xl shadow-xl overflow-hidden p-6 md:p-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 flex items-center">
            <Users className="w-8 h-8 mr-3 text-brand-600" />
            Espace Écrivain Public
          </h2>
          <p className="text-slate-500 mt-1">Gestion et historique des rendez-vous.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Rechercher un nom..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none w-full sm:w-64"
            />
          </div>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as any)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-white"
          >
            <option value="all">Tous les statuts</option>
            <option value="active">Actifs uniquement</option>
            <option value="cancelled">Annulés uniquement</option>
          </select>
          <button 
            onClick={() => setIsAuthenticated(false)}
            className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors font-medium"
          >
            Déconnexion
          </button>
        </div>
      </div>

      <div className="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-600 text-sm uppercase tracking-wider border-b border-slate-200">
                <th className="p-4 font-semibold">Date & Heure</th>
                <th className="p-4 font-semibold">Usager</th>
                <th className="p-4 font-semibold">Contact</th>
                <th className="p-4 font-semibold">Motif</th>
                <th className="p-4 font-semibold text-center">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {sortedAppointments.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500">
                    Aucun rendez-vous trouvé.
                  </td>
                </tr>
              ) : (
                sortedAppointments.map((app) => (
                  <tr key={app.id} className={`hover:bg-white transition-colors ${app.status === 'cancelled' ? 'opacity-60 bg-slate-50/50' : ''}`}>
                    <td className="p-4">
                      <div className="font-medium text-slate-800 flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-slate-400" />
                        {app.date.toLocaleDateString('fr-FR')}
                      </div>
                      <div className="text-sm text-slate-500 flex items-center mt-1">
                        <Clock className="w-4 h-4 mr-2 text-slate-400" />
                        {app.time}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="font-semibold text-slate-800">{app.user.lastName}</div>
                    </td>
                    <td className="p-4">
                      <div className="text-sm text-slate-800">{app.user.email}</div>
                      <div className="text-sm text-slate-500">{app.user.phone}</div>
                    </td>
                    <td className="p-4 max-w-xs">
                      <p className="text-sm text-slate-600 truncate" title={app.user.reason}>
                        {app.user.reason || <span className="italic text-slate-400">Non spécifié</span>}
                      </p>
                    </td>
                    <td className="p-4 text-center">
                      {app.status === 'active' ? (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Actif
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          <XCircle className="w-3 h-3 mr-1" /> Annulé
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
