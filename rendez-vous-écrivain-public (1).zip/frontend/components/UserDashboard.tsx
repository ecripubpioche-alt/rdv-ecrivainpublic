import React, { useState } from 'react';
import { Search, CalendarX, CalendarCheck, Clock, MapPin, AlertCircle } from 'lucide-react';
import { Appointment } from '../types';
import { getAppointmentsByEmail, cancelAppointment } from '../services/storageService';
import { formatDate } from '../utils/dateUtils';
import { CONTACT_INFO } from '../constants';

const UserDashboard: React.FC = () => {
  const [email, setEmail] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    
    const results = getAppointmentsByEmail(email.trim());
    setAppointments(results);
    setHasSearched(true);
  };

  const handleCancel = (id: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous ? Cette action est irréversible.')) {
      const success = cancelAppointment(id);
      if (success) {
        // Refresh list
        setAppointments(getAppointmentsByEmail(email.trim()));
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden p-6 md:p-10 animate-in fade-in duration-500">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Gérer mes rendez-vous</h2>
        <p className="text-slate-500">Entrez l'adresse email utilisée lors de la réservation pour retrouver vos rendez-vous.</p>
      </div>

      <form onSubmit={handleSearch} className="max-w-md mx-auto mb-10">
        <div className="relative">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="votre.email@exemple.com"
            className="w-full pl-12 pr-4 py-3 border-2 border-slate-200 rounded-xl focus:ring-0 focus:border-brand-500 outline-none transition-all text-lg"
          />
          <Search className="absolute left-4 top-3.5 text-slate-400 w-6 h-6" />
          <button 
            type="submit"
            className="absolute right-2 top-2 bottom-2 bg-brand-600 text-white px-4 rounded-lg font-medium hover:bg-brand-700 transition-colors"
          >
            Rechercher
          </button>
        </div>
      </form>

      {hasSearched && (
        <div className="space-y-6">
          <h3 className="text-xl font-semibold text-slate-800 border-b pb-2">
            Résultats pour <span className="text-brand-600">{email}</span>
          </h3>

          {appointments.length === 0 ? (
            <div className="bg-slate-50 p-8 rounded-2xl text-center text-slate-500">
              Aucun rendez-vous trouvé pour cette adresse email.
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {appointments.map((app) => {
                const isCancelled = app.status === 'cancelled';
                const isPast = app.date.getTime() < new Date().setHours(0,0,0,0);

                return (
                  <div 
                    key={app.id} 
                    className={`border-2 rounded-2xl p-5 relative overflow-hidden transition-all
                      ${isCancelled ? 'border-red-100 bg-red-50/50 opacity-75' : 
                        isPast ? 'border-slate-200 bg-slate-50 opacity-75' : 'border-brand-100 bg-white shadow-sm hover:shadow-md'}
                    `}
                  >
                    {isCancelled && (
                      <div className="absolute top-4 right-4 bg-red-100 text-red-700 text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">
                        Annulé
                      </div>
                    )}
                    
                    <div className="flex items-start mb-4">
                      <div className={`p-3 rounded-xl mr-4 ${isCancelled ? 'bg-red-100 text-red-600' : 'bg-brand-100 text-brand-600'}`}>
                        {isCancelled ? <CalendarX className="w-6 h-6" /> : <CalendarCheck className="w-6 h-6" />}
                      </div>
                      <div>
                        <p className="font-bold text-lg text-slate-800 capitalize">{formatDate(app.date)}</p>
                        <p className="text-slate-600 flex items-center mt-1">
                          <Clock className="w-4 h-4 mr-1" /> {app.time}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm text-slate-600 mb-6">
                      <p className="flex items-start">
                        <MapPin className="w-4 h-4 mr-2 mt-0.5 shrink-0" />
                        <span>{CONTACT_INFO.name}<br/>{CONTACT_INFO.address}</span>
                      </p>
                      {app.user.reason && (
                        <p className="flex items-start">
                          <AlertCircle className="w-4 h-4 mr-2 mt-0.5 shrink-0" />
                          <span className="line-clamp-2">Motif: {app.user.reason}</span>
                        </p>
                      )}
                    </div>

                    {!isCancelled && !isPast && (
                      <button
                        onClick={() => handleCancel(app.id)}
                        className="w-full py-2 border border-red-200 text-red-600 rounded-lg font-medium hover:bg-red-50 transition-colors"
                      >
                        Annuler ce rendez-vous
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
