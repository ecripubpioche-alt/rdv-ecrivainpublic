import React from 'react';
import { MapPin, Mail, Phone, Clock, HeartHandshake, CalendarDays } from 'lucide-react';
import { CONTACT_INFO, SERVICE_INFO } from '../constants';

const InfoSidebar: React.FC = () => {
  return (
    <div className="bg-brand-700 text-white rounded-2xl p-8 shadow-xl h-full flex flex-col">
      <div className="mb-8">
        <div className="inline-flex items-center justify-center p-3 bg-white/10 rounded-xl mb-4">
          <HeartHandshake className="w-8 h-8 text-brand-100" />
        </div>
        <h1 className="text-3xl font-bold mb-2">{SERVICE_INFO.title}</h1>
        <p className="text-brand-100 leading-relaxed">
          {SERVICE_INFO.description}
        </p>
      </div>

      <div className="space-y-6 flex-grow">
        <div className="flex items-start space-x-4">
          <MapPin className="w-6 h-6 text-brand-200 shrink-0 mt-1" />
          <div>
            <h3 className="font-semibold text-lg">Adresse</h3>
            <p className="text-brand-100">{CONTACT_INFO.name}</p>
            <p className="text-brand-100">{CONTACT_INFO.address}</p>
          </div>
        </div>

        <div className="flex items-start space-x-4">
          <Clock className="w-6 h-6 text-brand-200 shrink-0 mt-1" />
          <div>
            <h3 className="font-semibold text-lg">Permanences</h3>
            <ul className="text-brand-100 space-y-1 mt-1">
              <li>Mardi : 14h00 - 17h00</li>
              <li>Mercredi : 09h00 - 12h00</li>
              <li>Jeudi : 09h00 - 12h00</li>
            </ul>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Mail className="w-6 h-6 text-brand-200 shrink-0" />
          <a href={`mailto:${CONTACT_INFO.email}`} className="text-brand-100 hover:text-white transition-colors">
            {CONTACT_INFO.email}
          </a>
        </div>

        <div className="flex items-center space-x-4">
          <Phone className="w-6 h-6 text-brand-200 shrink-0" />
          <a href={`tel:${CONTACT_INFO.phone.replace(/\s/g, '')}`} className="text-brand-100 hover:text-white transition-colors">
            {CONTACT_INFO.phone}
          </a>
        </div>
      </div>

      <div className="mt-8 pt-8 border-t border-white/20">
        <div className="bg-white/10 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <CalendarDays className="w-5 h-5 text-brand-200" />
            <span className="font-medium">Durée du RDV</span>
          </div>
          <span className="font-bold">{SERVICE_INFO.duration}</span>
        </div>
        <div className="mt-4 text-center">
          <span className="inline-block bg-white text-brand-700 font-bold px-4 py-2 rounded-full text-sm uppercase tracking-wide shadow-sm">
            {SERVICE_INFO.price}
          </span>
        </div>
      </div>
    </div>
  );
};

export default InfoSidebar;
