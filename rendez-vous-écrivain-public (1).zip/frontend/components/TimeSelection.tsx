import React, { useMemo } from 'react';
import { Clock, ChevronLeft, ChevronRight } from 'lucide-react';
import { getAvailableSlots, formatDate } from '../utils/dateUtils';

interface TimeSelectionProps {
  selectedDate: Date;
  selectedTime: string | null;
  onSelectTime: (time: string) => void;
  onBack: () => void;
  onNext: () => void;
}

const TimeSelection: React.FC<TimeSelectionProps> = ({ 
  selectedDate, 
  selectedTime, 
  onSelectTime, 
  onBack, 
  onNext 
}) => {
  const slots = useMemo(() => getAvailableSlots(selectedDate), [selectedDate]);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6">
        <button 
          onClick={onBack}
          className="text-sm text-brand-600 hover:text-brand-800 flex items-center mb-4 font-medium transition-colors"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Retour aux dates
        </button>
        <h2 className="text-2xl font-bold text-slate-800 flex items-center">
          <Clock className="w-6 h-6 mr-2 text-brand-600" />
          Choisissez un horaire
        </h2>
        <p className="text-slate-500 mt-1">
          Créneaux disponibles pour le <strong className="text-slate-700">{formatDate(selectedDate)}</strong>
        </p>
      </div>

      {slots.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
          {slots.map((time) => {
            const isSelected = selectedTime === time;
            return (
              <button
                key={time}
                onClick={() => onSelectTime(time)}
                className={`
                  py-4 px-6 rounded-xl border-2 text-lg font-semibold transition-all duration-200
                  ${isSelected 
                    ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-md scale-105' 
                    : 'border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:bg-slate-50'}
                `}
              >
                {time}
              </button>
            );
          })}
        </div>
      ) : (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-lg mb-8">
          Aucun créneau disponible pour cette date. Veuillez sélectionner un autre jour.
        </div>
      )}

      <div className="flex justify-between items-center pt-6 border-t border-slate-100">
        <div className="text-sm text-slate-500">
          {selectedTime ? (
            <span>Heure choisie : <strong className="text-slate-800">{selectedTime}</strong></span>
          ) : (
            <span>Aucun horaire sélectionné</span>
          )}
        </div>
        <button
          onClick={onNext}
          disabled={!selectedTime}
          className={`
            flex items-center px-6 py-3 rounded-lg font-semibold transition-all
            ${selectedTime 
              ? 'bg-brand-600 text-white hover:bg-brand-700 shadow-md hover:shadow-lg' 
              : 'bg-slate-100 text-slate-400 cursor-not-allowed'}
          `}
        >
          Continuer
          <ChevronRight className="w-5 h-5 ml-2" />
        </button>
      </div>
    </div>
  );
};

export default TimeSelection;
