import React from 'react';
import { CheckCircle, Calendar, Clock, MapPin, Mail, AlertTriangle } from 'lucide-react';
import { Appointment } from '../types';
import { formatDate } from '../utils/dateUtils';
import { CONTACT_INFO } from '../constants';

interface ConfirmationScreenProps {
  appointment: Appointment;
  onReset: () => void;
  isEmailReal: boolean;
}

const ConfirmationScreen: React.FC<ConfirmationScreenProps> = ({ appointment, onReset, isEmailReal }) => {
  return (
    <div className="animate-in zoom-in-95 duration-500 flex flex-col items-center text-center py-8">
      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
        <CheckCircle className="w-12 h-12 text-green-600" />
      </div>
      
      <h2 className="text-3xl font-bold text-slate-800 mb-2">Rendez-vous confirmé !</h2>
      <p className="text-slate-600 mb-6 max-w-md">
        Merci {appointment.user.lastName}. Votre demande a bien été enregistrée.
      </p>

      {!isEmailReal && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl mb-8 max-w-md text-left text-sm flex items-start shadow-sm">
          <AlertTriangle className="w-5 h-5 mr-3 shrink-0 mt-0.5 text-amber-600" />
          <div>
            <strong className="block mb-1 font-semibold">Mode Démonstration</strong>
            L'email de confirmation n'a pas été réellement envoyé. Pour activer l'envoi d'emails, vous devez configurer vos clés API EmailJS dans le fichier <code className="bg-amber-100 px-1 rounded">services/emailService.ts</code>.
          </div>
        </div>
      )}

      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 w-full max-w-md text-left mb-8 shadow-sm">
        <h3 className="font-semibold text-slate-800 mb-4 border-b border-slate-200 pb-2">Récapitulatif</h3>
        
        <div className="space-y-4">
          <div className="flex items-start">
            <Calendar className="w-5 h-5 text-brand-600 mr-3 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm text-slate-500">Date</p>
              <p className="font-medium text-slate-800">{formatDate(appointment.date)}</p>
            </div>
          </div>
          
          <div className="flex items-start">
            <Clock className="w-5 h-5 text-brand-600 mr-3 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm text-slate-500">Heure</p>
              <p className="font-medium text-slate-800">{appointment.time}</p>
            </div>
          </div>

          <div className="flex items-start">
            <MapPin className="w-5 h-5 text-brand-600 mr-3 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm text-slate-500">Lieu</p>
              <p className="font-medium text-slate-800">{CONTACT_INFO.name}</p>
              <p className="text-sm text-slate-600">{CONTACT_INFO.address}</p>
            </div>
          </div>
          
          <div className="flex items-start">
            <Mail className="w-5 h-5 text-brand-600 mr-3 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm text-slate-500">Email de contact</p>
              <p className="font-medium text-slate-800">{appointment.user.email}</p>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={onReset}
        className="px-6 py-3 bg-white border-2 border-slate-200 text-slate-700 rounded-lg font-semibold hover:bg-slate-50 hover:border-slate-300 transition-all"
      >
        Prendre un autre rendez-vous
      </button>
    </div>
  );
};

export default ConfirmationScreen;
