import React, { useState } from 'react';
import { User, ChevronLeft, CheckCircle2, Loader2, Mail } from 'lucide-react';
import { UserDetails } from '../types';
import { formatDate } from '../utils/dateUtils';

interface UserDetailsFormProps {
  selectedDate: Date;
  selectedTime: string;
  onSubmit: (details: UserDetails) => Promise<void>;
  onBack: () => void;
}

const UserDetailsForm: React.FC<UserDetailsFormProps> = ({ 
  selectedDate, 
  selectedTime, 
  onSubmit, 
  onBack 
}) => {
  const [formData, setFormData] = useState<UserDetails>({
    lastName: '',
    email: '',
    phone: '',
    reason: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onSubmit(formData);
    } finally {
      // If successful, parent component will unmount this, so no need to set false unless error handling is added
      // setIsSubmitting(false); 
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-6">
        <button 
          onClick={onBack}
          disabled={isSubmitting}
          className="text-sm text-brand-600 hover:text-brand-800 flex items-center mb-4 font-medium transition-colors disabled:opacity-50"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Retour aux horaires
        </button>
        <h2 className="text-2xl font-bold text-slate-800 flex items-center">
          <User className="w-6 h-6 mr-2 text-brand-600" />
          Vos coordonnées
        </h2>
        <div className="mt-3 bg-brand-50 border border-brand-100 rounded-lg p-3 text-sm text-brand-800 flex items-center">
          <CheckCircle2 className="w-5 h-5 mr-2 text-brand-500 shrink-0" />
          <span>
            Réservation pour le <strong>{formatDate(selectedDate)}</strong> à <strong>{selectedTime}</strong>
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="lastName" className="block text-sm font-medium text-slate-700 mb-1">Nom *</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            required
            value={formData.lastName}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
            placeholder="Dupont"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">Email *</label>
            <input
              type="email"
              id="email"
              name="email"
              required
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
              placeholder="jean.dupont@exemple.com"
            />
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-1">Téléphone *</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              required
              value={formData.phone}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
              placeholder="06 12 34 56 78"
            />
          </div>
        </div>

        <div>
          <label htmlFor="reason" className="block text-sm font-medium text-slate-700 mb-1">Motif du rendez-vous (optionnel)</label>
          <textarea
            id="reason"
            name="reason"
            rows={3}
            value={formData.reason}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all resize-none"
            placeholder="Ex: Aide pour remplir un dossier CAF, rédaction d'un courrier..."
          ></textarea>
        </div>

        <div className="bg-blue-50 text-blue-800 p-4 rounded-lg text-sm flex items-start">
          <Mail className="w-5 h-5 mr-2 shrink-0 mt-0.5 text-blue-600" />
          <p>
            Un email de confirmation vous sera envoyé automatiquement, ainsi qu'à l'écrivain public, pour valider ce rendez-vous.
          </p>
        </div>

        <div className="pt-4 border-t border-slate-100 flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex items-center px-8 py-3 bg-brand-600 text-white rounded-lg font-semibold hover:bg-brand-700 shadow-md hover:shadow-lg transition-all disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Confirmation en cours...
              </>
            ) : (
              'Confirmer le rendez-vous'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default UserDetailsForm;
