import emailjs from '@emailjs/browser';
import { Appointment } from '../types';

// ============================================================================
// CONFIGURATION EMAILJS
// La clé publique (API Key) a été configurée.
// Note : Pour que l'envoi fonctionne parfaitement, assurez-vous que le 
// SERVICE_ID et le TEMPLATE_ID correspondent exactement à ceux créés 
// dans votre tableau de bord EmailJS.
// ============================================================================

export const EMAILJS_CONFIG = {
  SERVICE_ID: 'service_ecrivain',   // Remplacez par votre Service ID exact si différent
  TEMPLATE_ID: 'template_rdv',      // Remplacez par votre Template ID exact si différent
  PUBLIC_KEY: 'AQ.Ab8RN6JNktWkr1yAK5epzalFvC1x_OlpXFKqivSHVyeC0XQq1Q',
};

export const isEmailConfigured = (): boolean => {
  // Vérifie si la clé API a bien été insérée (et n'est pas la valeur par défaut)
  return EMAILJS_CONFIG.PUBLIC_KEY !== 'D9JQOnHcmsA66fhQx' && EMAILJS_CONFIG.PUBLIC_KEY.length > 0;
};

export const sendConfirmationEmails = async (appointment: Appointment): Promise<boolean> => {
  if (!isEmailConfigured()) {
    console.warn("⚠️ EmailJS n'est pas configuré. L'email n'a pas été réellement envoyé.");
    // Simulation d'attente pour ne pas bloquer l'interface si non configuré
    return new Promise(resolve => setTimeout(() => resolve(true), 1500));
  }

  try {
    // Ces paramètres doivent correspondre aux variables de votre template EmailJS
    // ex: {{to_name}}, {{appointment_date}}, etc.
    const templateParams = {
      to_name: appointment.user.lastName,
      to_email: appointment.user.email,
      appointment_date: appointment.date.toLocaleDateString('fr-FR'),
      appointment_time: appointment.time,
      user_phone: appointment.user.phone,
      user_reason: appointment.user.reason || 'Non spécifié',
      reply_to: 'ecri.pub.pioche@gmail.com'
    };

    await emailjs.send(
      EMAILJS_CONFIG.SERVICE_ID,
      EMAILJS_CONFIG.TEMPLATE_ID,
      templateParams,
      EMAILJS_CONFIG.PUBLIC_KEY
    );
    
    return true;
  } catch (error) {
    console.error("Erreur lors de l'envoi de l'email:", error);
    throw error;
  }
};
