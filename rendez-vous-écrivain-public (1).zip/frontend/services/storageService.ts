import { Appointment } from '../types';

const STORAGE_KEY = 'pioche_appointments_db';

// Helper to revive dates from JSON
const parseAppointments = (data: string | null): Appointment[] => {
  if (!data) return [];
  try {
    const parsed = JSON.parse(data);
    return parsed.map((app: any) => ({
      ...app,
      date: new Date(app.date),
      createdAt: new Date(app.createdAt)
    }));
  } catch (e) {
    console.error("Error parsing appointments from local storage", e);
    return [];
  }
};

export const saveAppointment = (appointment: Omit<Appointment, 'id' | 'status' | 'createdAt'>): Appointment => {
  const appointments = getAllAppointments();
  
  const newAppointment: Appointment = {
    ...appointment,
    id: Math.random().toString(36).substring(2, 15) + Date.now().toString(36),
    status: 'active',
    createdAt: new Date()
  };

  appointments.push(newAppointment);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appointments));
  
  return newAppointment;
};

export const getAllAppointments = (): Appointment[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  return parseAppointments(data).sort((a, b) => a.date.getTime() - b.date.getTime());
};

export const getAppointmentsByEmail = (email: string): Appointment[] => {
  const appointments = getAllAppointments();
  return appointments.filter(app => app.user.email.toLowerCase() === email.toLowerCase());
};

export const cancelAppointment = (id: string): boolean => {
  const appointments = getAllAppointments();
  const index = appointments.findIndex(app => app.id === id);
  
  if (index !== -1) {
    appointments[index].status = 'cancelled';
    localStorage.setItem(STORAGE_KEY, JSON.stringify(appointments));
    return true;
  }
  return false;
};
